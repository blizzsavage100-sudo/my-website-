# TEMi V LOG Ad Platform

## What is included
- `index.html` — TEMi V LOG website
- `server.js` — Express API + SQLite database
- `admin.html` — private moderation dashboard
- `package.json` — dependencies
- `.env.example` — environment-variable template

## Run locally
1. Install Node.js 20+.
2. In this folder run:
   `npm install`
3. Set an admin secret:
   Linux/macOS: `export ADMIN_TOKEN="your-long-secret"`
   Windows PowerShell: `$env:ADMIN_TOKEN="your-long-secret"`
4. Run:
   `npm start`
5. Open `http://localhost:3000`
6. Admin: `http://localhost:3000/admin`

## Important
The public website never receives the admin token. Keep it in your hosting provider's environment settings.

The database stores submitted ads as `pending`. Only ads approved in `/admin` are returned by `/api/ads`.

For production, use persistent disk/database hosting. Do not rely on ephemeral server storage if the host can erase local files on redeploy.
