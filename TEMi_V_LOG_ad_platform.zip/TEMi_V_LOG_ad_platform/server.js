import express from "express";
import Database from "better-sqlite3";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

if (!ADMIN_TOKEN) {
  console.warn("WARNING: Set ADMIN_TOKEN before using the admin API.");
}

const db = new Database(process.env.DB_FILE || "ads.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS ads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  location TEXT NOT NULL,
  description TEXT NOT NULL,
  contact TEXT NOT NULL,
  link TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TEXT
);
`);

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname)));

const blocked = /\b(drugs?|cocaine|heroin|meth|fentanyl|crack|marijuana|weed|cannabis|thc|illegal\s+substances?)\b/i;

function validAd(body) {
  const fields = ["category","title","location","description","contact"];
  if (!fields.every(k => typeof body[k] === "string" && body[k].trim())) return false;
  if (body.title.length > 80 || body.location.length > 80 || body.description.length > 700) return false;
  if (body.link && body.link.length > 500) return false;
  if (blocked.test(`${body.title} ${body.description}`)) return false;
  return true;
}

function admin(req, res, next) {
  const token = req.get("x-admin-token");
  if (!ADMIN_TOKEN || !token || !crypto.timingSafeEqual(Buffer.from(token), Buffer.from(ADMIN_TOKEN))) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

app.post("/api/ads", (req, res) => {
  if (!validAd(req.body)) return res.status(400).json({ error: "Invalid or prohibited advertisement." });

  const stmt = db.prepare(`
    INSERT INTO ads (category,title,location,description,contact,link)
    VALUES (@category,@title,@location,@description,@contact,@link)
  `);

  const result = stmt.run({
    category: req.body.category.trim(),
    title: req.body.title.trim(),
    location: req.body.location.trim(),
    description: req.body.description.trim(),
    contact: req.body.contact.trim(),
    link: (req.body.link || "").trim() || null
  });

  res.status(201).json({ id: result.lastInsertRowid, status: "pending" });
});

app.get("/api/ads", (req, res) => {
  const ads = db.prepare(`
    SELECT id,category,title,location,description,contact,link,created_at
    FROM ads WHERE status='approved' ORDER BY id DESC
  `).all();
  res.json(ads);
});

app.get("/api/admin/ads", admin, (req, res) => {
  res.json(db.prepare(`SELECT * FROM ads ORDER BY id DESC`).all());
});

app.patch("/api/admin/ads/:id", admin, (req, res) => {
  const status = req.body.status;
  if (!["approved","rejected","pending"].includes(status)) {
    return res.status(400).json({ error: "Invalid status." });
  }
  const result = db.prepare(`
    UPDATE ads SET status=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?
  `).run(status, Number(req.params.id));

  if (!result.changes) return res.status(404).json({ error: "Ad not found." });
  res.json({ ok: true });
});

app.delete("/api/admin/ads/:id", admin, (req, res) => {
  const result = db.prepare(`DELETE FROM ads WHERE id=?`).run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Ad not found." });
  res.json({ ok: true });
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "admin.html"));
});

app.listen(PORT, () => console.log(`TEMi V LOG ad platform running on port ${PORT}`));
